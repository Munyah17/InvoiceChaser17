const { createClient } = require('@supabase/supabase-js')

const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = SUPABASE_URL && SUPABASE_SERVICE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)
  : null

function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0
    const v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }
  }

  try {
    const body = JSON.parse(event.body)
    const {
      customerMsisdn,
      amount,
      reason,
      currency = 'USD',
      user_id,
      plan_id,
      metadata = {},
    } = body

    if (!customerMsisdn || !amount) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing customerMsisdn or amount' }) }
    }

    // Normalize phone: 077... -> 26377...
    let msisdn = String(customerMsisdn).replace(/\s/g, '').replace(/-/g, '')
    if (msisdn.startsWith('0')) {
      msisdn = '263' + msisdn.slice(1)
    }
    if (!msisdn.startsWith('263')) {
      msisdn = '263' + msisdn
    }

    const sourceReference = generateUUID()
    const apiKey = process.env.ECOCASH_API_KEY
    const isSandbox = process.env.ECOCASH_SANDBOX !== 'false'
    const endpoint = isSandbox
      ? 'https://developers.ecocash.co.zw/api/ecocash_pay/api/v2/payment/instant/c2b/sandbox'
      : 'https://developers.ecocash.co.zw/api/ecocash_pay/api/v2/payment/instant/c2b/live'

    if (!apiKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: 'ECOCASH_API_KEY not configured' }) }
    }

    const ecocashRes = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'X-API-KEY': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        customerMsisdn: msisdn,
        amount: parseFloat(amount),
        reason: reason || 'InvoiceChaser Payment',
        currency,
        sourceReference,
      }),
    })

    const ecocashData = await ecocashRes.json()

    // Record in Supabase
    if (supabase) {
      await supabase.from('payments').insert({
        user_id: user_id || null,
        amount: parseFloat(amount),
        currency,
        method: 'ecocash',
        status: ecocashRes.status === 200 ? 'pending' : 'failed',
        transaction_ref: sourceReference,
        metadata: {
          customerMsisdn: msisdn,
          plan_id: plan_id || null,
          ecocash_status: ecocashRes.status,
          ecocash_response: ecocashData,
          ...metadata,
        },
      })

      // Update profile plan if user is known
      if (user_id && ecocashRes.status === 200) {
        await supabase
          .from('profiles')
          .update({ plan: plan_id, updated_at: new Date().toISOString() })
          .eq('id', user_id)
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: ecocashRes.status === 200,
        sourceReference,
        status: ecocashRes.status,
        message:
          ecocashRes.status === 200
            ? 'Payment initiated. Check your phone for the EcoCash USSD prompt and enter your PIN.'
            : 'Failed to initiate EcoCash payment.',
        data: ecocashData,
      }),
    }
  } catch (error) {
    console.error('EcoCash payment error:', error)
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) }
  }
}
