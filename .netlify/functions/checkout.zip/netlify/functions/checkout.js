// Netlify Function: Create Stripe Checkout Session
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY)

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
}

exports.handler = async (event, context) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }
  }

  try {
    const body = JSON.parse(event.body)
    const {
      amount,
      name,
      plan_id,
      user_id,
      customer_email,
      customer_name,
      metadata = {},
    } = body

    if (!amount || !name) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing required fields: amount, name' }) }
    }

    const isSubscription = ['starter', 'professional', 'business'].includes(plan_id)
    const siteUrl = process.env.URL || process.env.DEPLOY_PRIME_URL || 'https://invoicechaser.netlify.app'

    const lineItem = {
      price_data: {
        currency: 'usd',
        product_data: {
          name: name,
          description: `InvoiceChaser ${name}`,
        },
        unit_amount: amount,
      },
      quantity: 1,
    }

    if (isSubscription) {
      lineItem.price_data.recurring = { interval: 'month' }
    }

    const sessionConfig = {
      mode: isSubscription ? 'subscription' : 'payment',
      payment_method_types: ['card'],
      line_items: [lineItem],
      metadata: {
        user_id: user_id || 'guest',
        plan_id: plan_id || 'default',
        ...metadata,
      },
      success_url: `${siteUrl}/payment-success?session_id={CHECKOUT_SESSION_ID}&plan=${plan_id}`,
      cancel_url: `${siteUrl}/checkout?plan=${plan_id}`,
      automatic_tax: { enabled: true },
      allow_promotion_codes: true,
    }

    if (customer_email) {
      sessionConfig.customer_email = customer_email
    }

    const session = await stripe.checkout.sessions.create(sessionConfig)

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ url: session.url, session_id: session.id, mode: sessionConfig.mode }),
    }
  } catch (error) {
    console.error('Checkout error:', error)
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) }
  }
}
