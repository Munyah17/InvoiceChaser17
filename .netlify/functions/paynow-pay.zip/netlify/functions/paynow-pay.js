const { Paynow } = require('paynow')
const { createClient } = require('@supabase/supabase-js')

const SUPABASE_URL = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = SUPABASE_URL && SUPABASE_SERVICE_KEY
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)
  : null

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json',
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers }
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }
  }

  try {
    const body = JSON.parse(event.body)
    const { method, phone, amount, description, reference, email, user_id, plan_id } = body

    if (!amount || !description || !reference) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing required fields' }) }
    }

    const integrationId = process.env.PAYNOW_INTEGRATION_ID || '23792'
    const integrationKey = process.env.PAYNOW_INTEGRATION_KEY

    if (!integrationKey) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: 'PAYNOW_INTEGRATION_KEY not configured' }) }
    }

    const paynow = new Paynow(integrationId, integrationKey)
    const siteUrl = process.env.URL || process.env.DEPLOY_PRIME_URL || 'https://vocal-paletas-03d14f.netlify.app'

    paynow.resultUrl = `${siteUrl}/api/paynow-result`
    paynow.returnUrl = `${siteUrl}/payment-success?method=paynow&plan=${plan_id || 'professional'}&ref=${reference}`

    const payment = paynow.createPayment(reference, email || 'customer@invoicechaser.com')
    payment.add(description, parseFloat(amount))

    let response
    if (method === 'web') {
      response = await paynow.send(payment)
    } else if (method === 'ecocash' || method === 'onemoney') {
      if (!phone) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Phone number required for mobile payment' }) }
      }
      // Normalize phone
      let mobile = String(phone).replace(/\s/g, '').replace(/-/g, '')
      if (mobile.startsWith('0')) {
        mobile = mobile.slice(1)
      }
      response = await paynow.sendMobile(payment, mobile, method)
    } else {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid Paynow method' }) }
    }

    if (!response.success) {
      return {
        statusCode: 402,
        headers,
        body: JSON.stringify({ error: response.error || 'Paynow transaction failed' }),
      }
    }

    // Record in Supabase
    if (supabase) {
      await supabase.from('payments').insert({
        user_id: user_id || null,
        amount: parseFloat(amount),
        currency: 'USD',
        method: 'paynow',
        status: 'pending',
        transaction_ref: reference,
        metadata: {
          paynow_poll_url: response.pollUrl,
          paynow_method: method,
          paynow_reference: reference,
        },
      })
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        url: response.redirectUrl,
        instructions: response.instructions,
        pollUrl: response.pollUrl,
        reference,
      }),
    }
  } catch (error) {
    console.error('Paynow payment error:', error)
    return { statusCode: 500, headers, body: JSON.stringify({ error: error.message }) }
  }
}
